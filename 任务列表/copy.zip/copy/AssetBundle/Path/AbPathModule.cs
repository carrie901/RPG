﻿using UnityEngine;
using System.Collections;

namespace Summer
{
    /// <summary>
    /// 路径模块 分为外部路径和内部路径
    /// 外部路径:根据平台不同，根据加载方式的不同有不同的路径
    /// 内部路径:不同类型的资源，存放的内部路径不一致
    /// </summary>
    public class AbPathModule
    {

    }
}


