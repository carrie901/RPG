﻿using UnityEngine;
using System.Collections;

namespace Summer
{
    public class BuffNormal : Buff
    {


    }
}


