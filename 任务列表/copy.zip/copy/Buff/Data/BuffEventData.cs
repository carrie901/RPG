﻿
/// <summary>
/// 来一个BuffEventData的缓存池
/// </summary>
public class EventSetData
{
    public virtual void Reset() { }
}


public class IntValueEventBuff : EventSetData
{
    public int value;
}

public class TargetEventBuff : EventSetData
{

    public iCharacterBaseController target;
}

public class BuffLayerMaxEventBuff : EventSetData
{

    public Buff buff;
    public override void Reset() { buff = null; }
}



/// <summary>
/// 把所有的Event的Factory合并到一起
/// </summary>
public class EventDataFactory
{
    public static T Pop<T>() where T : EventSetData, new()
    {
        T t = new T();
        return t;
    }

    public static void Push<T>(T t) where T : EventSetData
    {
        if (t != null)
            t.Reset();
    }
}
