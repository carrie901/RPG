﻿using UnityEngine;
using System.Collections;


/// <summary>
/// 做掉这个ID charID由服务器得到，从服务器得到的这个ID 可以被客户端应用也可以被服务器应用
/// </summary>
/*
public class CharId
{
    static uint iidex = 0;
    public uint iid;

    public CharId()
    {
        iid = iidex;
        iidex++;
    }

    public bool EqualId(CharId id)
    {
        return iid == id.iid;
    }
}
*/
