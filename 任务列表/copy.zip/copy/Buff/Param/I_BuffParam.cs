﻿using UnityEngine;
using System.Collections;

public interface I_BuffParam
{
    void ParseParam(string content);
}

public interface I_BuffProcessData
{
    
}
