﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class buffContextManager
{
    public static Dictionary<GameObject, buffContextModule> SkillContextDic = new Dictionary<GameObject, buffContextModule>();

    public static void bindContext(GameObject useSkill, buffContextModule module)
    {
        if(SkillContextDic.ContainsKey(useSkill))
        {
            Debug.Log("已经存在");
        }
        else
        {
            SkillContextDic.Add(useSkill,module);
        }
    }

    public static buffContextModule GetCurrentBuffContext(GameObject SkillPrefab)
    {
        if(SkillContextDic.ContainsKey(SkillPrefab))
        {
            return SkillContextDic[SkillPrefab];
        }
        else
        {
            Debug.Log("Buff PlayerMaker不存在");
            return null;
        }
    }

    public static void RemoveContextDic(GameObject obj)
    {
        if (SkillContextDic.ContainsKey(obj))
        {
            SkillContextDic.Remove(obj);
        }
        else
        {
            Debug.Log("删除Buff PlayerMaker不存在");
        }
    }
}