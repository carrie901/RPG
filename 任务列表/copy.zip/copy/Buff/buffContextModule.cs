﻿using System;
using System.Collections.Generic;
using UnityEngine;

public class buffContextModule
{
    int buffID;
    //添加buff的对应技能
    int buffSkillId = 0;
    //buff的施法者
    iCharacterBaseController buffCaster = null;
    //buff的接受者
    iCharacterBaseController buffTarget = null;

    uint buffTimeEventId = 0;

    string mMainController = @"MainController";
    string mActionController = @"ActionController";
    string mSkillerController = @"SkillerController";
    string mHitController = @"HitController";
    PlayMakerFSM mainControllerFsm = null;
    PlayMakerFSM mActionControllerFsm = null;
    PlayMakerFSM mSkillerControllerFsm = null;
    PlayMakerFSM mHitControllerFsm = null;
    void InitFsmController()
    {
        if (BuffMainObject != null)
        {
            PlayMakerFSM[] _fsmList = BuffMainObject.GetComponents<PlayMakerFSM>();
            for (int i = 0; i < _fsmList.Length; i++)
            {
                if (_fsmList[i].FsmName == mMainController)
                {
                    mainControllerFsm = _fsmList[i];
                    if (mainControllerFsm.enabled == false)
                    {
                        mainControllerFsm.enabled = true;
                    }
                }
                if (_fsmList[i].FsmName.Equals(mActionController))
                {
                    mActionControllerFsm = _fsmList[i];
                    if (mActionControllerFsm.enabled == false)
                    {
                        mActionControllerFsm.enabled = true;
                    }
                }
                if (_fsmList[i].FsmName.Equals(mSkillerController))
                {
                    mSkillerControllerFsm = _fsmList[i];
                    if (mSkillerControllerFsm.enabled == false)
                        mSkillerControllerFsm.enabled = true;
                }
                if (_fsmList[i].FsmName.Equals(mHitController))
                {
                    mHitControllerFsm = _fsmList[i];
                    if (mHitControllerFsm.enabled == false)
                        mHitControllerFsm.enabled = true;
                }
            }
        }
    }

    public void SendAllFsmEvent(string EvnetName)
    {
        if (mainControllerFsm != null) mainControllerFsm.SendEvent(EvnetName);
        if (mActionControllerFsm != null) mActionControllerFsm.SendEvent(EvnetName);
        if (mSkillerControllerFsm != null) mSkillerControllerFsm.SendEvent(EvnetName);
        if (mHitControllerFsm != null) mHitControllerFsm.SendEvent(EvnetName);
    }

    public void SetFsmParamter(string name, int value)
    {
        if (mainControllerFsm != null) PMHelper.SetFsmParamter(mainControllerFsm, name, value);
        if (mActionControllerFsm != null) PMHelper.SetFsmParamter(mActionControllerFsm, name, value);
        if (mSkillerControllerFsm != null) PMHelper.SetFsmParamter(mSkillerControllerFsm, name, value);
        if (mHitControllerFsm != null) PMHelper.SetFsmParamter(mHitControllerFsm, name, value);
    }

    public void SetFsmParamter(string name, bool value)
    {
        if (mainControllerFsm != null) PMHelper.SetFsmParamter(mainControllerFsm, name, value);
        if (mActionControllerFsm != null) PMHelper.SetFsmParamter(mActionControllerFsm, name, value);
        if (mSkillerControllerFsm != null) PMHelper.SetFsmParamter(mSkillerControllerFsm, name, value);
        if (mHitControllerFsm != null) PMHelper.SetFsmParamter(mHitControllerFsm, name, value);
    }

    public void SetFsmParamter(string name, string value)
    {
        if (mainControllerFsm != null) PMHelper.SetFsmParamter(mainControllerFsm, name, value);
        if (mActionControllerFsm != null) PMHelper.SetFsmParamter(mActionControllerFsm, name, value);
        if (mSkillerControllerFsm != null) PMHelper.SetFsmParamter(mSkillerControllerFsm, name, value);
        if (mHitControllerFsm != null) PMHelper.SetFsmParamter(mHitControllerFsm, name, value);
    }

    public void SetFsmParamter(string name, GameObject value)
    {
        if (mainControllerFsm != null) PMHelper.SetFsmParamter(mainControllerFsm, name, value);
        if (mActionControllerFsm != null) PMHelper.SetFsmParamter(mActionControllerFsm, name, value);
        if (mSkillerControllerFsm != null) PMHelper.SetFsmParamter(mSkillerControllerFsm, name, value);
        if (mHitControllerFsm != null) PMHelper.SetFsmParamter(mHitControllerFsm, name, value);
    }

    public void SetFsmParamter(string name, Vector3 value)
    {
        if (mainControllerFsm != null) PMHelper.SetFsmParamter(mainControllerFsm, name, value);
        if (mActionControllerFsm != null) PMHelper.SetFsmParamter(mainControllerFsm, name, value);
        if (mSkillerControllerFsm != null) PMHelper.SetFsmParamter(mainControllerFsm, name, value);
        if (mHitControllerFsm != null) PMHelper.SetFsmParamter(mainControllerFsm, name, value);
    }

    GameObject BuffMainObject = null;

    public void Start(int buffid,iCharacterBaseController Caster,iCharacterBaseController target,int skilltemplateID)
    {
        buffID = buffid;
        buffCaster = Caster;
        buffTarget = target;
        buffSkillId = skilltemplateID;
        BuffPlayObject bpo = GameObjectPoolManager.Instance.GetObject<BuffPlayObject>(null);
        if(bpo != null)
        {
            BuffMainObject = bpo.gameObject;
        }
        else
        {
            BuffMainObject = null;
        }
        InitFsmController();
        BuffMainObject.SetActive(true);
        //连接buff
        buffContextManager.bindContext(BuffMainObject,this);
        TimerEventObject _autoFinished = TimerEventCreater.Timer<TimerEventObject>();
        buffTimeEventId = TimeDispatcher.Timer(BuffAutoStopTimerEventHandler, _autoFinished, 5.0f, false);

    }

    private void BuffAutoStopTimerEventHandler(float time, TimerEventObject _timerEvent)
    {
        buffTimeEventId = 0;
    }

    public void BuffStop()
    {
        if (buffTimeEventId != 0)
            TimeDispatcher.Discard(buffTimeEventId);
        if (mainControllerFsm != null)
        {
            mainControllerFsm.enabled = false;
            mainControllerFsm = null;
        }
        if (mActionControllerFsm != null)
        {
            mActionControllerFsm.enabled = false;
            mActionControllerFsm = null;
        }
        if (mSkillerControllerFsm != null)
        {
            mSkillerControllerFsm.enabled = false;
            mSkillerControllerFsm = null;
        }
        if (mHitControllerFsm != null)
        {
            mHitControllerFsm.enabled = false;
            mHitControllerFsm = null;
        }
        if (BuffMainObject != null)
        {
            SkillContextManager.RemoveContextDic(BuffMainObject);
            GameObjectPoolManager.Instance.Discard<BuffPlayObject>(BuffMainObject);
        }
    }
    
    

}
