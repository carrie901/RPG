﻿
namespace Summer
{
    /// <summary>
    /// 效果类型=属性
    /// </summary>
    public class EffectAttributeData : I_EffectParam
    {

        public bool _is_positive;                       //正负
        public E_CharDataUpdateType _calc_type;         //+1 or +1%
        public int _calc_data;                          //value

        public void ParseParam(string param)
        {
            string[] contents = StringHelper.SplitString(param);

            _is_positive = int.Parse(contents[0]) == 0;
            _calc_type = (E_CharDataUpdateType)int.Parse(contents[1]);
            _calc_data = int.Parse(contents[2]);

            if (!_is_positive)
                _calc_data = 0 - _calc_data;

        }

    }

}
