﻿namespace Summer
{
    /// <summary>
    /// 数值属性
    /// </summary>
    public class EffectValueData : I_BuffParam
    {
        public E_CharDataUpdateType _calc_type;         // +1 or +1%
        public int _calc_data;                          // value


        public void ParseParam(string param)
        {
            string[] contents = StringHelper.SplitString(param);

            _calc_type = (E_CharDataUpdateType)int.Parse(contents[0]);
            _calc_data = int.Parse(contents[1]);
        }
    }
}

