﻿using UnityEngine;
using System.Collections;

namespace Summer
{
    /// <summary>
    /// 修改属性
    /// </summary>
    public class EffectAttribute : SEffect
    {
        public EffectAttributeData _param = new EffectAttributeData();
        public E_CharAttributeRegion _region;
        public float _cumulative_data;


        public override void _on_parse()
        {
            _region = (E_CharAttributeRegion)cnf.sub_type;
            _param.ParseParam(cnf.param1);
        }

        public override bool _on_excute()
        {

            // 1.找到要更新的属性
            PropertyIntParam property_value = _owner.property.FindProperty(_region);
            // 2.根据层级计算属性具体伤害值（如果直接计算层级最终的结果。那么再重新增加层级的时候，进行reset操作，再添加）

            int origin = property_value.Value;

            // 3.按照百分比/固定值更新属性
            BuffHelper.Calc(property_value, _param._calc_type, _param._calc_data);
            Log("effect id:[{3}] excute--->Attribute:[{0}],before:[{1}],after[{2}]", _region, origin, property_value.Value, cnf.ID);
            _cumulative_data += _param._calc_data;
            return false;
        }

        public override void _on_reverse()
        {

            // 1.找到要更新的属性
            PropertyIntParam property_value = _owner.property.FindProperty(_region);
            // 2.根据层级计算属性具体伤害值（如果直接计算层级最终的结果。那么再重新增加层级的时候，进行reset操作，再添加）
            int origin = property_value.Value;
            // 3.按照百分比/固定值更新属性
            BuffHelper.Calc(property_value, _param._calc_type, -(int)_cumulative_data);
            Log("effect id:[{3}] reverse--->Attribute:[{0}],before:[{1}],after[{2}]", _region, origin, property_value.Value, cnf.ID);
        }
    }
}

