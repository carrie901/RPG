﻿namespace Summer
{
    public class EffectAttributeMoveSpeed : SEffect
    {

        public EffectAttributeData _param = new EffectAttributeData();
        public E_CharAttributeRegion _region;
        public float _cumulative_data;
        public override void _on_parse()
        {
            _region = E_CharAttributeRegion.move_speed;
            _param.ParseParam(cnf.param1);
        }

        public override bool _on_excute()
        {
            if (_owner == null)
            {
                Error("目标为空");
                return false;
            }
            float origin = _owner.speed;
            if (_param._calc_type == E_CharDataUpdateType.multiply_plus)
            {
                _owner.ChangeMoveSpeedMultiplyPlus(_param._calc_data);
            }
            else if (_param._calc_type == E_CharDataUpdateType.plus)
            {
                _owner.ChangeeMoveSpeed(_param._calc_data / 100f);
            }
            Log("effect id: [{3}] excute Attribute is [{0}], before:[{1}],after[{2}]", _region, origin, _owner.speed, cnf.ID);
            _cumulative_data += _param._calc_data;
            return false;
        }

        public override void _on_reverse()
        {
            float origin = _owner.speed;
            if (_param._calc_type == E_CharDataUpdateType.multiply_plus)
            {
                _owner.ChangeMoveSpeedMultiplyPlus(-_cumulative_data);
            }
            else if (_param._calc_type == E_CharDataUpdateType.plus)
            {
                _owner.ChangeeMoveSpeed(-(_cumulative_data / 100f));
            }
            Log("effect id: [{3}] reverse Attribute:[{0}],before:[{1}],after[{2}]", _region, origin, _owner.speed, cnf.ID);
        }
    }

}

