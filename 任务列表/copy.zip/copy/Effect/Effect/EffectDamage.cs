﻿
namespace Summer
{
    /// <summary>
    /// 对目标造成多少多少伤害
    /// </summary>
    public class EffectDamage : SEffect
    {
        public E_EffectDamgeAndhealth _damge_type;
        public int value;
        public override void _on_parse()
        {
            _damge_type = (E_EffectDamgeAndhealth)cnf.sub_type;
            value = int.Parse(cnf.param1);
        }

        public override bool _on_excute()
        {
            float damge = -EffectHelper.FindDamgeByType(_owner, _damge_type, value);

            Log("伤害类型[{0}],伤害参数[{1}],对目标造成[{2}]伤害", _damge_type, value, damge);
            DamageInterFace.CalculaterBuffDamage(_owner, (int)damge);
            return false;
        }

        public override void _on_reverse()
        {


        }
    }

}

