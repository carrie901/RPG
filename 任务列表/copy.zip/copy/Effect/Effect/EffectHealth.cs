﻿
namespace Summer
{
    /// <summary>
    /// 治疗效果
    /// </summary>
    public class EffectHealth : SEffect
    {
        public E_EffectDamgeAndhealth _health_type;
        public int value;
        public override void _on_parse()
        {
            _health_type = (E_EffectDamgeAndhealth)cnf.sub_type;
            value = int.Parse(cnf.param1);
        }

        public override bool _on_excute()
        {
            float health_value = EffectHelper.FindDamgeByType(_owner, _health_type, value);

            Log("effect id:[{0}] excute--->effect type:[{0}],health target:[{1}]", cnf.ID, _health_type, health_value);
            DamageInterFace.CalculaterBuffTreatment(_owner, (int)health_value);
            return false;

        }

        public override void _on_reverse()
        {


        }
    }
}

