﻿using UnityEngine;
using System.Collections;

namespace Summer
{
    public class EffectPeerLess : SEffect
    {
        public EffectAttributeData _param = new EffectAttributeData();
        public override void _on_parse()
        {
            _param.ParseParam(cnf.param1);
        }

        public override bool _on_excute()
        {
            float origin = _owner.peerLess.FindMax();
            float cur = 0;
            BuffHelper.Calc(origin, ref cur, _param._calc_type, _param._calc_data);
            if (cur > 0)
                _owner.peerLess.AddAnger(cur);
            else
                _owner.peerLess.ReduceAnger(cur);
            Log("effect id:[{0}] excute--->Attribute:[{1}],before:[{2}],after[{3}]", cnf.ID, "无双", origin, _owner.peerLess.GetValue());
            return false;
        }

        public override void _on_reverse()
        {

        }
    }

}
