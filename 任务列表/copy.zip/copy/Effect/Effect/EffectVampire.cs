﻿

namespace Summer
{
    /// <summary>
    /// 自身攻击造成目标造成的伤害
    /// 以伤害值的百分比或者固定值为自身恢复生命
    /// </summary>
    public class EffectVampire : EffectValue
    {

        /*public override void OnAttach(iCharacterBaseController target)
        {
            base.OnAttach(target);
            _owner.RegisterHandler(E_AbilityTrigger.on_attack_enemy_damage, _on_attack_enemy);
        }

        public override void OnDetach()
        {
            base.OnDetach();
            _owner.UnRegisterHandler(E_AbilityTrigger.on_attack_enemy_damage, _on_attack_enemy);
        }*/

        //自身收到伤害的时候，回复血量
        public void _on_attack_enemy(EventSetData param)
        {
            CharOpertionCharInfo opertion_info = param as CharOpertionCharInfo;
            if (opertion_info == null) return;

            // 1.如果不是伤害返回
            if (!opertion_info.is_damage()) return;

            float tmp_curr = 0;
            float origin = opertion_info.value;
            BuffHelper.Calc(origin, ref tmp_curr, _param._calc_type, _param._calc_data);
            DamageInterFace.CalculaterBuffTreatment(opertion_info._target, (int)tmp_curr);
            Log("自身攻击造成目标造成的伤害,以伤害值的百分比或者固定值为自身恢复生命--->对目标造成伤害[0],治疗自身[1]", _region, origin, tmp_curr);
        }
    }

}
