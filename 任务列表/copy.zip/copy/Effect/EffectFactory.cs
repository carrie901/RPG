﻿using UnityEngine;

namespace Summer
{
    public class EffectFactory
    {
        public static SEffect Create(int effect_id, iCharacterBaseController owner)
        {
            if (effect_id == 0) return null;

            SEffect effect = null;
            BuffEffectObj effect_obj = StaticData.GetData<BuffEffectObj>(effect_id);
            if (effect_obj == null) return null;

            E_EffectType effect_type = (E_EffectType)effect_obj.type;


            switch (effect_type)
            {
                case E_EffectType.value:
                    effect = _create_value(effect_obj);
                    break;
                case E_EffectType.attribute:
                    effect = _create_attribute(effect_obj);
                    break;
                case E_EffectType.change_state:
                    effect = _create_changestate(effect_obj);
                    break;
                case E_EffectType.damge:
                    effect = _create_damge(effect_obj);
                    break;
                case E_EffectType.health:
                    effect = _create_health(effect_obj);
                    break;
                case E_EffectType.action:
                    effect = _create_action(effect_obj);
                    break;
                case E_EffectType.absorb_damage:
                    effect = _create_absorb_damage(effect_obj);
                    break;
                case E_EffectType.peerless:
                    effect = new EffectPeerLess();
                    break;
            }
            if (effect != null)
                effect.Init(effect_obj, owner);
            return effect;
        }

        public static SEffect _create_value(BuffEffectObj effect_obj)
        {
            Debug.Log("目前没有开始写创建数值效果");


            return null;
        }

        public static SEffect _create_attribute(BuffEffectObj effect_obj)
        {
            SEffect attribute = null;
            if (effect_obj.sub_type == (int)E_CharAttributeRegion.move_speed)
            {
                attribute = new EffectAttributeMoveSpeed();
            }
            else
            {
                attribute = new EffectAttribute();
            }


            return attribute;
        }

        public static SEffect _create_action(BuffEffectObj effect_obj)
        {
            SEffect effect = null;
            if (effect_obj.sub_type == (int)E_EffectBuff.add_buff)
            {
                effect = new EffectBuffAdd();
            }
            else if (effect_obj.sub_type == (int)E_EffectBuff.remove_buff)
            {
                effect = new EffectBuffRemove();
            }
            else
            {
                SEffect.Error("效果动作还没开始做");
            }
            return effect;
        }

        public static SEffect _create_changestate(BuffEffectObj effect_obj)
        {
            SEffect effect = null;
            E_EffectState state = (E_EffectState)effect_obj.sub_type;

            switch (state)
            {
                case E_EffectState.frozen:
                    effect = new EffectFrozen();
                    break;
                case E_EffectState.invincible:
                    effect = new EffectInvincible();
                    break;
                case E_EffectState.sealskill:
                    effect = new EffectSealSkill();
                    break;
            }

            return effect;
        }

        public static SEffect _create_damge(BuffEffectObj effect_obj)
        {
            SEffect effect = new EffectDamage();
            return effect;
        }

        public static SEffect _create_health(BuffEffectObj effect_obj)
        {
            SEffect effect = new EffectHealth();
            return effect;
        }

        public static SEffect _create_absorb_damage(BuffEffectObj effect_obj)
        {
            SEffect effect = new EffectAbsorbDamage();
            return effect;
        }
    }


}
