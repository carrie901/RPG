﻿using UnityEngine;
using System.Collections;

namespace Summer
{
/*    public interface I_Effect
    {

        void OnExcute(iCharacterBaseController target);
        void OnReverse(iCharacterBaseController target);
    }*/
}

