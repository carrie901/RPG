﻿
namespace Summer
{
    /// <summary>
    /// 解析效果参数
    /// </summary>
    public interface I_EffectParam
    {
        void ParseParam(string content);
    }
}


