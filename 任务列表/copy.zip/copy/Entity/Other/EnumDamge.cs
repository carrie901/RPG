﻿
namespace Summer
{

    /// <summary>
    /// 伤害类型
    /// </summary>
    public enum E_AbilityUnitDamageType
    {
        damage_type_magical,            // 魔法伤害 魔法伤害会被魔抗减少
        damage_type_physical,           // 物理伤害 物理伤害会被护甲和格挡（圆盾）减少
        damage_type_pure,               // 真实伤害/混合伤害 真实伤害/混合伤害不会被任何护甲或魔抗减少
    }
}


