﻿using UnityEngine;
using System.Collections;

namespace Summer
{
    public class GameObjectHelper
    {
        /// <summary>
        /// Activates/Deactivates the GameObject.
        /// </summary>
        public static void SetActive(GameObject obj, bool value)
        {
            if (obj.activeSelf == value) return;
            obj.SetActive(value);
        }

        /// <summary>
        /// 归一化Tran的坐标旋转缩放
        /// </summary>
        /// <param name="trans"></param>
        public static void Normalize(Transform trans)
        {
            trans.localPosition = Vector3.zero;
            trans.localScale = Vector3.one;
            trans.localEulerAngles = Vector3.zero;
        }
    }
}

