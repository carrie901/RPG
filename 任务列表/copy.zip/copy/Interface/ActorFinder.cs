﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ActorFinder : TSingleton<ActorFinder>
{
    /*public iCharacterBaseController FindChar(uint char_id)
    {
        List<iCharacterBaseController> charlist = cCharacterManager.AllCharacter;
        for (int i = 0; i < charlist.Count; i++)
        {
            iCharacterBaseController conrtoller = charlist[i];
            if (conrtoller.ID == char_id)
            {
                return conrtoller;
            }
        }
        //cCharacterManager.Instance.get
        return null;
    }*/
}
