﻿using UnityEngine;
using System.Collections;

namespace Summer
{
    public class App : MonoBehaviour
    {

        private void Awake()
        {

        }


        // Use this for initialization
        void Start()
        {

        }

        // Update is called once per frame
        void Update()
        {

        }

        void OnApplicationQuit()
        {
            LogManager.Quit();
        }
    }
}